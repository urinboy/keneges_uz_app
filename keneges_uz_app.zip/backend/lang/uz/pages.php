<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Sahifa tillari qatorlari
    |--------------------------------------------------------------------------
    |
    */

    "home" => "Asosiy sahifa",
    "dashboard" => "Boshqaruv paneli",
    "profile" => "Shaxsiy xona",
    "settings" => "Sozlamalar",
    "faq" => "Savol javob",
    "news" => "Yangiliklar",

];
