<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Autentifikatsiya tillari qatorlari
    |--------------------------------------------------------------------------
    |
    */

    'failed' => 'Bu hisob ma\'lumotlari bizning yozuvlarimizga mos kelmaydi.',
    'password' => 'Taqdim etilgan parol noto\'g\'ri.',
    'throttle' => 'Kirish uchun juda ko\'p urinishlar. Iltimos, :seconds soniyadan keyin qayta urinib ko\'ring.',
    'login'   => 'Kirish',
    'register'   => 'Ro\'yxatdan o\'tish',
    'aleady_register'   => 'Allaqachon ro\'yxatdan o\'tganmisiz?',
    'logout'   => 'Chiqish',
    'username'   => 'Foydalanuvchi ismi',
    'email'   => 'Elektron pochta',
    'password'   => 'Parol',
    'cpassword'   => 'Parolni tasdiqlash',
    'upassword'   => 'Parolni yangilash',
    'curpassword'   => 'Joriy parol',
    'newpassword'   => 'Yangi parol',
    'delaccount'   => 'Hisobni o\'chirish',

];
