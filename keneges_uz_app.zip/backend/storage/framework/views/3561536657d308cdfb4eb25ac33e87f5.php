<!-- Notifications menu -->
<li
    class="relative px-2 py-1 rounded-md bg-gray-100 hover:text-gray-800 dark:bg-gray-800 dark:hover:text-gray-200 dark:text-gray-100">
    <button
        class="flex justify-center align-middle font-semibold rounded-md focus:outline-none focus:shadow-outline-green"
        @click="toggleNotificationsMenu" @keydown.escape="closeNotificationsMenu" aria-label="Notifications"
        aria-haspopup="true">
        <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129" />
        </svg>
        <?php $__currentLoopData = config('app.available_locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(app()->getLocale() == $locale): ?>
                <?php echo e(strtoupper($locale)); ?>

            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </button>

    <template x-if="isNotificationsMenuOpen">
        <ul x-transition:leave="transition ease-in duration-150" x-transition:leave-start="opacity-100"
            x-transition:leave-end="opacity-0" @click.away="closeNotificationsMenu"
            @keydown.escape="closeNotificationsMenu"
            class="absolute right-0 w-56 p-2 mt-2 space-y-2 text-gray-600 bg-white border border-gray-100 rounded-md shadow-md dark:text-gray-300 dark:border-gray-700 dark:bg-gray-700">

            <?php $__currentLoopData = config('app.available_locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.lang-link','data' => ['href' => route(\Illuminate\Support\Facades\Route::currentRouteName(), [
                    'locale' => $locale,
                ]),'active' => app()->getLocale() == $locale]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('lang-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route(\Illuminate\Support\Facades\Route::currentRouteName(), [
                    'locale' => $locale,
                ])),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(app()->getLocale() == $locale)]); ?>

                    <?php switch(strtolower($locale)):
                        case ('uz'): ?>
                            O'zbekcha
                        <?php break; ?>

                        <?php case ('oz'): ?>
                            Ўзбекча
                        <?php break; ?>

                        <?php case ('qr'): ?>
                            Qaraqalpaqsha
                        <?php break; ?>

                        <?php case ('kr'): ?>
                            Қарақалпақша
                        <?php break; ?>

                        <?php default: ?>
                    <?php endswitch; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </template>
</li>
<?php /**PATH D:\Dasturlar\OSPanel\domains\keneges_uz_app\backend\resources\views/components/lang.blade.php ENDPATH**/ ?>