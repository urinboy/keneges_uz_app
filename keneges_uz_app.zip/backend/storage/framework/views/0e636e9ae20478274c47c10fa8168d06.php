

<img src="/assets/images/logos/k-logo-257.png" alt="<?php echo e(config('app.name', 'Laravel')); ?>"  <?php echo e($attributes); ?>>
<?php /**PATH D:\Dasturlar\OSPanel\domains\keneges_uz_app\backend\resources\views/components/application-logo.blade.php ENDPATH**/ ?>