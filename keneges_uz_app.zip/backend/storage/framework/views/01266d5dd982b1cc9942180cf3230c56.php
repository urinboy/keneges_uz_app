<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('pages.dashboard')); ?>

     <?php $__env->endSlot(); ?>

    
    <div class="py-2">
        <div class="max-w-7xl mx-auto sm:px-2 lg:px-3">
            <div class="bg-white dark:bg-gray-800 dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-2 text-gray-900 dark:text-gray-100">

                    <section class="my-3 text-center">
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
                            <div class="relative mb-12 px-3 lg:mb-0">
                                <div class="mb-2 flex justify-center">
                                    <span class="text-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                            fill="currentColor" class="h-14 w-14">
                                            <path
                                                d="M12.378 1.602a.75.75 0 00-.756 0L3 6.632l9 5.25 9-5.25-8.622-5.03zM21.75 7.93l-9 5.25v9l8.628-5.032a.75.75 0 00.372-.648V7.93zM11.25 22.18v-9l-9-5.25v8.57a.75.75 0 00.372.648l8.628 5.033z" />
                                        </svg>
                                    </span>
                                </div>
                                <h5 class="mb-6 font-bold text-primary">5000+</h5>
                                <h6 class="mb-0 font-normal dark:text-neutral-50">Components</h6>
                                <div
                                    class="absolute top-0 right-0 hidden h-full min-h-[1em] w-px self-stretch border-t-0 bg-gradient-to-tr from-transparent via-neutral-500 to-transparent opacity-25 dark:opacity-100 lg:block">
                                </div>
                            </div>
                            <div class="relative mb-12 px-3 lg:mb-0">
                                <div class="mb-2 flex justify-center">
                                    <span class="text-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                            fill="currentColor" class="h-14 w-14">
                                            <path
                                                d="M11.644 1.59a.75.75 0 01.712 0l9.75 5.25a.75.75 0 010 1.32l-9.75 5.25a.75.75 0 01-.712 0l-9.75-5.25a.75.75 0 010-1.32l9.75-5.25z" />
                                            <path
                                                d="M3.265 10.602l7.668 4.129a2.25 2.25 0 002.134 0l7.668-4.13 1.37.739a.75.75 0 010 1.32l-9.75 5.25a.75.75 0 01-.71 0l-9.75-5.25a.75.75 0 010-1.32l1.37-.738z" />
                                            <path
                                                d="M10.933 19.231l-7.668-4.13-1.37.739a.75.75 0 000 1.32l9.75 5.25c.221.12.489.12.71 0l9.75-5.25a.75.75 0 000-1.32l-1.37-.738-7.668 4.13a2.25 2.25 0 01-2.134-.001z" />
                                        </svg>
                                    </span>
                                </div>
                                <h5 class="mb-6 font-bold text-primary">490+</h5>
                                <h6 class="mb-0 font-normal dark:text-neutral-50">Design blocks</h6>
                                <div
                                    class="absolute top-0 right-0 hidden h-full min-h-[1em] w-px self-stretch border-t-0 bg-gradient-to-tr from-transparent via-neutral-500 to-transparent opacity-25 dark:opacity-100 lg:block">
                                </div>
                            </div>
                            <div class="relative mb-12 px-3 lg:mb-0">
                                <div class="mb-2 flex justify-center">
                                    <span class="text-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                            fill="currentColor" class="h-14 w-14">
                                            <path fill-rule="evenodd"
                                                d="M1.5 6a2.25 2.25 0 012.25-2.25h16.5A2.25 2.25 0 0122.5 6v12a2.25 2.25 0 01-2.25 2.25H3.75A2.25 2.25 0 011.5 18V6zM3 16.06V18c0 .414.336.75.75.75h16.5A.75.75 0 0021 18v-1.94l-2.69-2.689a1.5 1.5 0 00-2.12 0l-.88.879.97.97a.75.75 0 11-1.06 1.06l-5.16-5.159a1.5 1.5 0 00-2.12 0L3 16.061zm10.125-7.81a1.125 1.125 0 112.25 0 1.125 1.125 0 01-2.25 0z"
                                                clip-rule="evenodd" />
                                        </svg>
                                    </span>
                                </div>
                                <h5 class="mb-6 font-bold text-primary">100+</h5>
                                <h6 class="mb-0 font-normal dark:text-neutral-50">Templates</h6>
                                <div
                                    class="absolute top-0 right-0 hidden h-full min-h-[1em] w-px self-stretch border-t-0 bg-gradient-to-tr from-transparent via-neutral-500 to-transparent opacity-25 dark:opacity-100 lg:block">
                                </div>
                            </div>
                            <div class="relative mb-12 px-3 lg:mb-0">
                                <div class="mb-2 flex justify-center">
                                    <span class="text-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                            fill="currentColor" class="h-14 w-14">
                                            <path fill-rule="evenodd"
                                                d="M11.078 2.25c-.917 0-1.699.663-1.85 1.567L9.05 4.889c-.02.12-.115.26-.297.348a7.493 7.493 0 00-.986.57c-.166.115-.334.126-.45.083L6.3 5.508a1.875 1.875 0 00-2.282.819l-.922 1.597a1.875 1.875 0 00.432 2.385l.84.692c.095.078.17.229.154.43a7.598 7.598 0 000 1.139c.015.2-.059.352-.153.43l-.841.692a1.875 1.875 0 00-.432 2.385l.922 1.597a1.875 1.875 0 002.282.818l1.019-.382c.115-.043.283-.031.45.082.312.214.641.405.985.57.182.088.277.228.297.35l.178 1.071c.151.904.933 1.567 1.85 1.567h1.844c.916 0 1.699-.663 1.85-1.567l.178-1.072c.02-.12.114-.26.297-.349.344-.165.673-.356.985-.57.167-.114.335-.125.45-.082l1.02.382a1.875 1.875 0 002.28-.819l.923-1.597a1.875 1.875 0 00-.432-2.385l-.84-.692c-.095-.078-.17-.229-.154-.43a7.614 7.614 0 000-1.139c-.016-.2.059-.352.153-.43l.84-.692c.708-.582.891-1.59.433-2.385l-.922-1.597a1.875 1.875 0 00-2.282-.818l-1.02.382c-.114.043-.282.031-.449-.083a7.49 7.49 0 00-.985-.57c-.183-.087-.277-.227-.297-.348l-.179-1.072a1.875 1.875 0 00-1.85-1.567h-1.843zM12 15.75a3.75 3.75 0 100-7.5 3.75 3.75 0 000 7.5z"
                                                clip-rule="evenodd" />
                                        </svg>
                                    </span>
                                </div>
                                <h5 class="mb-6 font-bold text-primary">28</h5>
                                <h6 class="mb-0 font-normal dark:text-neutral-50">Plugins</h6>
                            </div>
                        </div>
                    </section>

                    


                </div>
            </div>
        </div>
    </div>
    

    

    <!-- Container for demo purpose -->
    <div class="container my-2 px-6 mx-auto">

        <!-- Section: Design Block -->
        <section class="mb-3 text-gray-800">
            <!-- CTA -->
            <a class="flex items-center justify-between p-4 mb-8 text-sm font-semibold text-blue-100 bg-blue-600 rounded-lg shadow-md focus:outline-none focus:shadow-outline-blue"
                href="https://keneges.uz">
                <div class="flex items-center">
                    <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z">
                        </path>
                    </svg>
                    <span>Main Projects</span>
                </div>
                <span>View more &RightArrow;</span>
            </a>

            

            <div class="grid lg:grid-cols-3 gap-6">
                <div class="relative overflow-hidden bg-no-repeat bg-cover shadow-lg rounded-lg"
                    style="background-position: 50%;" data-mdb-ripple="true" data-mdb-ripple-color="light">
                    <img src="https://mdbootstrap.com/img/new/standard/nature/051.jpg" class="w-full" />
                    <a href="#!">
                        <div class="absolute top-0 right-0 bottom-0 left-0 w-full h-full overflow-hidden bg-fixed"
                            style="background-color: rgba(0, 0, 0, 0.4)">
                            <div class="flex justify-start items-end h-full">
                                <div class="text-white m-6">
                                    <h5 class="font-bold text-lg mb-3">I miss the sun</h5>
                                    <p>
                                        <small>Published <u>13.01.2022</u> by Anna Maria Doe</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="relative overflow-hidden bg-no-repeat bg-cover shadow-lg rounded-lg" data-mdb-ripple="true"
                    data-mdb-ripple-color="light">
                    <img src="https://mdbootstrap.com/img/new/standard/nature/044.jpg" class="w-full" />
                    <a href="#!">
                        <div class="absolute top-0 right-0 bottom-0 left-0 w-full h-full overflow-hidden bg-fixed"
                            style="background-color: rgba(0, 0, 0, 0.4)">
                            <div class="flex justify-start items-end h-full">
                                <div class="text-white m-6">
                                    <h5 class="font-bold text-lg mb-3">Adventure in the desert</h5>
                                    <p>
                                        <small>Published <u>12.01.2022</u> by Mark Equel</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="relative overflow-hidden bg-no-repeat bg-cover shadow-lg rounded-lg" data-mdb-ripple="true"
                    data-mdb-ripple-color="light">
                    <img src="https://mdbootstrap.com/img/new/standard/nature/045.jpg" class="w-full" />
                    <a href="#!">
                        <div class="absolute top-0 right-0 bottom-0 left-0 w-full h-full overflow-hidden bg-fixed"
                            style="background-color: rgba(0, 0, 0, 0.4)">
                            <div class="flex justify-start items-end h-full">
                                <div class="text-white m-6">
                                    <h5 class="font-bold text-lg mb-3">Lonely mountain</h5>
                                    <p>
                                        <small>Published <u>10.01.2022</u> by Bilbo baggins</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="relative overflow-hidden bg-no-repeat bg-cover shadow-lg rounded-lg" data-mdb-ripple="true"
                    data-mdb-ripple-color="light">
                    <img src="https://mdbootstrap.com/img/new/standard/nature/047.jpg" class="w-full" />
                    <a href="#!">
                        <div class="absolute top-0 right-0 bottom-0 left-0 w-full h-full overflow-hidden bg-fixed"
                            style="background-color: rgba(0, 0, 0, 0.4)">
                            <div class="flex justify-start items-end h-full">
                                <div class="text-white m-6">
                                    <h5 class="font-bold text-lg mb-3">Let's go!</h5>
                                    <p>
                                        <small>Published <u>09.01.2022</u> by Halley Frank</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="relative overflow-hidden bg-no-repeat bg-cover shadow-lg rounded-lg" data-mdb-ripple="true"
                    data-mdb-ripple-color="light">
                    <img src="https://mdbootstrap.com/img/new/standard/nature/028.jpg" class="w-full" />
                    <a href="#!">
                        <div class="absolute top-0 right-0 bottom-0 left-0 w-full h-full overflow-hidden bg-fixed"
                            style="background-color: rgba(0, 0, 0, 0.4)">
                            <div class="flex justify-start items-end h-full">
                                <div class="text-white m-6">
                                    <h5 class="font-bold text-lg mb-3">A hut in the mountains</h5>
                                    <p>
                                        <small>Published <u>07.01.2022</u> by David Beak</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="relative overflow-hidden bg-no-repeat bg-cover shadow-lg rounded-lg"
                    data-mdb-ripple="true" data-mdb-ripple-color="light">
                    <img src="https://mdbootstrap.com/img/new/standard/nature/049.jpg" class="w-full" />
                    <a href="#!">
                        <div class="absolute top-0 right-0 bottom-0 left-0 w-full h-full overflow-hidden bg-fixed"
                            style="background-color: rgba(0, 0, 0, 0.4)">
                            <div class="flex justify-start items-end h-full">
                                <div class="text-white m-6">
                                    <h5 class="font-bold text-lg mb-3">Beautiful waterfall</h5>
                                    <p>
                                        <small>Published <u>04.01.2022</u> by Joe Svan</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>

        </section>
        <!-- Section: Design Block -->

    </div>
    <!-- Container for demo purpose -->

    <!-- Container for demo purpose -->
    <div class="container my-2 px-6 mx-auto">

        <!-- Section: Design Block -->
        <section class="mb-3  text-gray-900 dark:text-gray-100 text-center">

            <h2 class="text-3xl font-bold mb-12 pb-4 text-center"><?php echo e(__('Latest articles')); ?></h2>

            <div class="grid lg:grid-cols-3 gap-6 xl:gap-x-12">
                <div class="mb-6 lg:mb-0">
                    <div class="relative block bg-white dark:bg-gray-800 rounded-lg shadow-lg">
                        <div class="flex">
                            <div class="relative overflow-hidden bg-no-repeat bg-cover relative overflow-hidden bg-no-repeat bg-cover shadow-lg rounded-lg mx-4 -mt-4"
                                data-mdb-ripple="true" data-mdb-ripple-color="light">
                                <img src="https://mdbcdn.b-cdn.net/img/new/standard/city/024.webp" class="w-full" />
                                <a href="#!">
                                    <div class="absolute top-0 right-0 bottom-0 left-0 w-full h-full overflow-hidden bg-fixed opacity-0 hover:opacity-100 transition duration-300 ease-in-out"
                                        style="background-color: rgba(251, 251, 251, 0.15)"></div>
                                </a>
                            </div>
                        </div>
                        <div class="p-6">
                            <h5 class="font-bold text-lg mb-3">My paradise</h5>
                            <p class="text-gray-500 mb-4">
                                <small>Published <u>13.01.2022</u> by
                                    <a href="" class="text-gray-900">Anna Maria Doe</a></small>
                            </p>
                            <p class="mb-4 pb-2">
                                Ut pretium ultricies dignissim. Sed sit amet mi eget urna
                                placerat vulputate. Ut vulputate est non quam dignissim
                                elementum. Donec a ullamcorper diam.
                            </p>
                            <a href="#!" data-mdb-ripple="true" data-mdb-ripple-color="light"
                                class="inline-block px-6 py-2.5 bg-blue-600 text-white font-medium text-xs leading-tight uppercase rounded-full shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out">Read
                                more</a>
                        </div>
                    </div>
                </div>

                <div class="mb-6 lg:mb-0">
                    <div class="relative block bg-white dark:bg-gray-800 rounded-lg shadow-lg">
                        <div class="flex">
                            <div class="relative overflow-hidden bg-no-repeat bg-cover relative overflow-hidden bg-no-repeat bg-cover shadow-lg rounded-lg mx-4 -mt-4"
                                data-mdb-ripple="true" data-mdb-ripple-color="light">
                                <img src="https://mdbcdn.b-cdn.net/img/new/standard/city/031.webp" class="w-full" />
                                <a href="#!">
                                    <div class="absolute top-0 right-0 bottom-0 left-0 w-full h-full overflow-hidden bg-fixed opacity-0 hover:opacity-100 transition duration-300 ease-in-out"
                                        style="background-color: rgba(251, 251, 251, 0.15)"></div>
                                </a>
                            </div>
                        </div>
                        <div class="p-6">
                            <h5 class="font-bold text-lg mb-3">Travel to Italy</h5>
                            <p class="text-gray-500 mb-4">
                                <small>Published <u>12.01.2022</u> by
                                    <a href="" class="text-gray-900">Halley Frank</a></small>
                            </p>
                            <p class="mb-4 pb-2">
                                Suspendisse in volutpat massa. Nulla facilisi. Sed aliquet
                                diam orci, nec ornare metus semper sed. Integer volutpat
                                ornare erat sit amet rutrum.
                            </p>
                            <a href="#!" data-mdb-ripple="true" data-mdb-ripple-color="light"
                                class="inline-block px-6 py-2.5 bg-blue-600 text-white font-medium text-xs leading-tight uppercase rounded-full shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out">Read
                                more</a>
                        </div>
                    </div>
                </div>

                <div class="mb-0">
                    <div class="relative block bg-white dark:bg-gray-800 rounded-lg shadow-lg">
                        <div class="flex">
                            <div class="relative overflow-hidden bg-no-repeat bg-cover relative overflow-hidden bg-no-repeat bg-cover shadow-lg rounded-lg mx-4 -mt-4"
                                data-mdb-ripple="true" data-mdb-ripple-color="light">
                                <img src="https://mdbcdn.b-cdn.net/img/new/standard/city/081.webp" class="w-full" />
                                <a href="#!">
                                    <div class="absolute top-0 right-0 bottom-0 left-0 w-full h-full overflow-hidden bg-fixed opacity-0 hover:opacity-100 transition duration-300 ease-in-out"
                                        style="background-color: rgba(251, 251, 251, 0.15)"></div>
                                </a>
                            </div>
                        </div>
                        <div class="p-6">
                            <h5 class="font-bold text-lg mb-3">Chasing the sun</h5>
                            <p class="text-gray-500 mb-4">
                                <small>Published <u>10.01.2022</u> by
                                    <a href="" class="text-gray-900">Joe Svan</a></small>
                            </p>
                            <p class="mb-4 pb-2">
                                Curabitur tristique, mi a mollis sagittis, metus felis mattis
                                arcu, non vehicula nisl dui quis diam. Mauris ut risus eget
                                massa volutpat feugiat. Donec.
                            </p>
                            <a href="#!" data-mdb-ripple="true" data-mdb-ripple-color="light"
                                class="inline-block px-6 py-2.5 bg-blue-600 text-white font-medium text-xs leading-tight uppercase rounded-full shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out">Read
                                more</a>
                        </div>
                    </div>
                </div>
            </div>

        </section>
        <!-- Section: Design Block -->

    </div>
    <!-- Container for demo purpose -->

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Dasturlar\OSPanel\domains\keneges_uz_app\backend\resources\views/dashboard.blade.php ENDPATH**/ ?>